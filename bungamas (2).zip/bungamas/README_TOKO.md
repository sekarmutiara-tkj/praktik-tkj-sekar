# Fitur Toko BungaMas

1. Aktifkan Apache dan MySQL di XAMPP.
2. Buat/import database melalui phpMyAdmin dengan `database/bungamas.sql`.
3. Letakkan folder `bungamas` di `C:\xampp\htdocs\`.
4. Buka `http://localhost/bungamas/`.
5. Admin: username `admin`, password `admin123`.
6. Pembeli dapat daftar melalui menu Daftar.
7. Ongkir otomatis dihitung berdasarkan provinsi tujuan. Tarif dapat diubah pada tabel `ongkir`.
8. Produk dan harga seed mengikuti harga project sebelumnya: basah Rp5.000/kg, kering Rp30.000/kg, Starter Rp25.000/10 bibit, UMKM Rp100.000/50 bibit, Mitra Rp450.000/250 bibit.
9. Nomor WhatsApp toko pada modul baru mengikuti nomor yang tampil di project ini: 6285659084770.
10. Nomor rekening dan DANA dapat diisi pada tabel `pengaturan` melalui phpMyAdmin.
