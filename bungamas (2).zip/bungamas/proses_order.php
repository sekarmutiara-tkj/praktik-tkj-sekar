<?php

require_once 'includes/functions.php';

wajib_login('pembeli');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: toko.php');
    exit;
}

$pid = (int)($_POST['produk_id'] ?? 0);
$jumlah = max(1, (int)($_POST['jumlah'] ?? 1));

try {

    $pdo->beginTransaction();

    // Ambil data produk
    $q = $pdo->prepare("
        SELECT *
        FROM produk
        WHERE id = ?
        AND aktif = 1
        FOR UPDATE
    ");

    $q->execute([$pid]);
    $p = $q->fetch();

    if (!$p) {
        throw new Exception('Produk tidak ditemukan.');
    }

    if ($jumlah > (int)$p['stok']) {
        throw new Exception('Stok tidak mencukupi.');
    }

    // Data checkout
    $nama_penerima = trim($_POST['nama_penerima'] ?? '');
    $no_whatsapp = trim($_POST['no_whatsapp'] ?? '');
    $alamat = trim($_POST['alamat'] ?? '');
    $provinsi = trim($_POST['provinsi'] ?? '');
    $kota = trim($_POST['kota'] ?? '');
    $catatan = trim($_POST['catatan'] ?? '');
    $metode_pembayaran = trim($_POST['metode_pembayaran'] ?? 'WhatsApp');

    if ($nama_penerima === '') {
        throw new Exception('Nama penerima wajib diisi.');
    }

    if ($no_whatsapp === '') {
        throw new Exception('Nomor WhatsApp wajib diisi.');
    }

    if ($alamat === '') {
        throw new Exception('Alamat wajib diisi.');
    }

    if ($provinsi === '') {
        throw new Exception('Provinsi wajib dipilih.');
    }

    if ($kota === '') {
        throw new Exception('Kota wajib diisi.');
    }

    // Cek ongkir berdasarkan provinsi
    $oq = $pdo->prepare("
        SELECT tarif
        FROM ongkir
        WHERE provinsi = ?
        LIMIT 1
    ");

    $oq->execute([$provinsi]);

    $ongkir = (float)($oq->fetchColumn() ?? 0);

    // Hitung harga
    $harga = (float)$p['harga'];
    $subtotal = $harga * $jumlah;
    $total = $subtotal + $ongkir;

    // Validasi metode pembayaran
    $metode_valid = [
        'Transfer Bank',
        'DANA',
        'WhatsApp'
    ];

    if (!in_array($metode_pembayaran, $metode_valid, true)) {
        $metode_pembayaran = 'WhatsApp';
    }

    // Buat kode pesanan
    $kode = kode_pesanan();

    // Simpan pesanan
    $q = $pdo->prepare("
        INSERT INTO pesanan (
            kode_pesanan,
            user_id,
            nama_penerima,
            no_whatsapp,
            alamat,
            provinsi,
            kota,
            catatan,
            subtotal,
            ongkir,
            total,
            metode_pembayaran
        ) VALUES (
            ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?
        )
    ");

    $q->execute([
        $kode,
        $_SESSION['user_id'],
        $nama_penerima,
        $no_whatsapp,
        $alamat,
        $provinsi,
        $kota,
        $catatan,
        $subtotal,
        $ongkir,
        $total,
        $metode_pembayaran
    ]);

    $orderId = $pdo->lastInsertId();

    // Simpan detail pesanan
    $q = $pdo->prepare("
        INSERT INTO pesanan_detail (
            pesanan_id,
            produk_id,
            nama_produk,
            harga,
            jumlah,
            subtotal
        ) VALUES (?, ?, ?, ?, ?, ?)
    ");

    $q->execute([
        $orderId,
        $pid,
        $p['nama_produk'],
        $harga,
        $jumlah,
        $subtotal
    ]);

    // Kurangi stok
    $q = $pdo->prepare("
        UPDATE produk
        SET stok = stok - ?
        WHERE id = ?
    ");

    $q->execute([
        $jumlah,
        $pid
    ]);

    $pdo->commit();

    header('Location: sukses.php?id=' . $orderId);
    exit;

} catch (Throwable $e) {

    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }

    die('Pesanan gagal: ' . e($e->getMessage()));
}

?>