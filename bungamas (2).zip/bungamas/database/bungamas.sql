CREATE DATABASE IF NOT EXISTS bungamas CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE bungamas;

CREATE TABLE IF NOT EXISTS users (
 id INT AUTO_INCREMENT PRIMARY KEY,
 nama VARCHAR(100) NOT NULL,
 username VARCHAR(50) NOT NULL UNIQUE,
 email VARCHAR(120) DEFAULT NULL,
 password VARCHAR(255) NOT NULL,
 role ENUM('admin','pembeli') NOT NULL DEFAULT 'pembeli',
 no_whatsapp VARCHAR(20) DEFAULT NULL,
 alamat TEXT DEFAULT NULL,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS produk (
 id INT AUTO_INCREMENT PRIMARY KEY,
 nama_produk VARCHAR(150) NOT NULL,
 deskripsi TEXT,
 harga DECIMAL(15,2) NOT NULL DEFAULT 0,
 satuan VARCHAR(30) NOT NULL DEFAULT 'pcs',
 stok INT NOT NULL DEFAULT 0,
 gambar VARCHAR(255) DEFAULT NULL,
 aktif TINYINT(1) NOT NULL DEFAULT 1,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS ongkir (
 id INT AUTO_INCREMENT PRIMARY KEY,
 provinsi VARCHAR(100) NOT NULL UNIQUE,
 tarif DECIMAL(15,2) NOT NULL DEFAULT 0
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS pesanan (
 id INT AUTO_INCREMENT PRIMARY KEY,
 kode_pesanan VARCHAR(30) NOT NULL UNIQUE,
 user_id INT NOT NULL,
 nama_penerima VARCHAR(100) NOT NULL,
 no_whatsapp VARCHAR(20) NOT NULL,
 alamat TEXT NOT NULL,
 provinsi VARCHAR(100) NOT NULL,
 kota VARCHAR(100) NOT NULL,
 catatan TEXT DEFAULT NULL,
 subtotal DECIMAL(15,2) NOT NULL DEFAULT 0,
 ongkir DECIMAL(15,2) NOT NULL DEFAULT 0,
 total DECIMAL(15,2) NOT NULL DEFAULT 0,
 metode_pembayaran ENUM('Transfer Bank','DANA','WhatsApp') NOT NULL DEFAULT 'WhatsApp',
 status_pembayaran ENUM('Belum Bayar','Menunggu Verifikasi','Lunas') NOT NULL DEFAULT 'Belum Bayar',
 status_pesanan ENUM('Menunggu','Diproses','Dikirim','Selesai','Dibatalkan') NOT NULL DEFAULT 'Menunggu',
 bukti_pembayaran VARCHAR(255) DEFAULT NULL,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 CONSTRAINT fk_pesanan_user FOREIGN KEY (user_id) REFERENCES users(id) ON UPDATE CASCADE ON DELETE RESTRICT
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS pesanan_detail (
 id INT AUTO_INCREMENT PRIMARY KEY,
 pesanan_id INT NOT NULL,
 produk_id INT NOT NULL,
 nama_produk VARCHAR(150) NOT NULL,
 harga DECIMAL(15,2) NOT NULL,
 jumlah INT NOT NULL,
 subtotal DECIMAL(15,2) NOT NULL,
 CONSTRAINT fk_detail_pesanan FOREIGN KEY (pesanan_id) REFERENCES pesanan(id) ON UPDATE CASCADE ON DELETE CASCADE,
 CONSTRAINT fk_detail_produk FOREIGN KEY (produk_id) REFERENCES produk(id) ON UPDATE CASCADE ON DELETE RESTRICT
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS pengaturan (
 id INT AUTO_INCREMENT PRIMARY KEY,
 nama_toko VARCHAR(150) NOT NULL DEFAULT 'BungaMas',
 whatsapp VARCHAR(20) NOT NULL DEFAULT '6285659084770',
 nama_bank VARCHAR(100) NOT NULL DEFAULT 'Bank Transfer',
 nomor_rekening VARCHAR(100) NOT NULL DEFAULT 'ISI_NOMOR_REKENING',
 nama_rekening VARCHAR(100) NOT NULL DEFAULT 'BungaMas',
 nomor_dana VARCHAR(100) NOT NULL DEFAULT 'ISI_NOMOR_DANA'
) ENGINE=InnoDB;

INSERT INTO users (nama,username,email,password,role,no_whatsapp) VALUES
('Administrator','admin','admin@bungamas.local','$2y$12$7sQqXqpSbeulgRJs31QEsuQ8d24.Ur2SvQmoYQ452USHXmd4jhGHa','admin','6285659084770')
ON DUPLICATE KEY UPDATE username=username;

INSERT INTO produk (nama_produk,deskripsi,harga,satuan,stok,gambar) VALUES
('Bunga Mas Basah','Bunga Mas segar/basah, dijual berdasarkan kilogram.','5000','kg',1000,'images/bunga1.png'),
('Bunga Mas Kering','Bunga Mas kering hasil proses pengeringan, dijual berdasarkan kilogram.','30000','kg',500,'images/bunga2.png'),
('Paket Bibit Starter','Paket 10 bibit Bunga Mas untuk memulai budidaya.','25000','10 bibit',100,'images/kemitraan.png'),
('Paket Bibit UMKM','Paket 50 bibit Bunga Mas untuk pengembangan skala UMKM.','100000','50 bibit',100,'images/kemitraan.png'),
('Paket Bibit Mitra','Paket 250 bibit Bunga Mas untuk program kemitraan.','450000','250 bibit',50,'images/kemitraan.png')
ON DUPLICATE KEY UPDATE nama_produk=VALUES(nama_produk);

INSERT INTO ongkir (provinsi,tarif) VALUES
('Jawa Barat',10000),
('DKI Jakarta',15000),
('Banten',15000),
('Jawa Tengah',20000),
('DI Yogyakarta',20000),
('Jawa Timur',25000),
('Bali',30000),
('Sumatera Utara',35000),
('Sumatera Barat',35000),
('Riau',35000),
('Kepulauan Riau',40000),
('Jambi',35000),
('Sumatera Selatan',35000),
('Bengkulu',35000),
('Lampung',30000),
('Kepulauan Bangka Belitung',40000),
('Kalimantan Barat',40000),
('Kalimantan Tengah',40000),
('Kalimantan Selatan',40000),
('Kalimantan Timur',45000),
('Kalimantan Utara',50000),
('Sulawesi Utara',50000),
('Sulawesi Tengah',50000),
('Sulawesi Selatan',50000),
('Sulawesi Tenggara',50000),
('Gorontalo',50000),
('Sulawesi Barat',50000),
('Maluku',60000),
('Maluku Utara',60000),
('Papua',75000),
('Papua Barat',75000)
ON DUPLICATE KEY UPDATE tarif=VALUES(tarif);

INSERT INTO pengaturan (id) VALUES (1)
ON DUPLICATE KEY UPDATE id=id;