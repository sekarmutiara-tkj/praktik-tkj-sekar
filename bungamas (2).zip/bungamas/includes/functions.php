<?php

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once __DIR__ . '/../config/database.php';


/* =========================
   ESCAPE HTML
========================= */

function e($v)
{
    return htmlspecialchars(
        (string)$v,
        ENT_QUOTES,
        'UTF-8'
    );
}


/* =========================
   FORMAT RUPIAH
========================= */

function rupiah($v)
{
    return 'Rp ' . number_format(
        (float)$v,
        0,
        ',',
        '.'
    );
}


/* =========================
   CEK LOGIN
========================= */

function wajib_login($role = null)
{
    /*
     * Kalau belum login,
     * kembali ke login.php yang benar.
     */
    if (empty($_SESSION['user_id'])) {

        header(
            'Location: /BungaMas_Toko/bungamas/login.php'
        );

        exit;
    }


    /*
     * Kalau halaman membutuhkan role tertentu,
     * cek role user.
     */
    if (
        $role !== null &&
        ($_SESSION['role'] ?? '') !== $role
    ) {

        /*
         * ADMIN
         */
        if (($_SESSION['role'] ?? '') === 'admin') {

            header(
                'Location: /BungaMas_Toko/bungamas/admin/dashboard.php'
            );

            exit;
        }


        /*
         * PEMBELI
         */
        if (($_SESSION['role'] ?? '') === 'pembeli') {

            header(
                'Location: /BungaMas_Toko/bungamas/toko.php'
            );

            exit;
        }


        /*
         * Kalau role tidak dikenali
         */
        header(
            'Location: /BungaMas_Toko/bungamas/'
        );

        exit;
    }
}


/* =========================
   LOGIN USER
========================= */

function user_login($username, $password)
{
    global $pdo;

    $q = $pdo->prepare("
        SELECT *
        FROM users
        WHERE username = ?
           OR email = ?
        LIMIT 1
    ");

    $q->execute([
        $username,
        $username
    ]);

    $u = $q->fetch();


    if (
        $u &&
        password_verify(
            $password,
            $u['password']
        )
    ) {

        /*
         * Regenerate session ID
         * setelah login.
         */
        session_regenerate_id(true);

        $_SESSION['user_id'] = $u['id'];
        $_SESSION['nama']    = $u['nama'];
        $_SESSION['role']    = $u['role'];

        return true;
    }


    return false;
}


/* =========================
   KODE PESANAN
========================= */

function kode_pesanan()
{
    return 'BM-' .
        date('YmdHis') .
        '-' .
        random_int(100, 999);
}


/* =========================
   WHATSAPP
========================= */

function whatsapp_url($number, $text)
{
    return 'https://wa.me/' .
        preg_replace('/\D/', '', $number) .
        '?text=' .
        rawurlencode($text);
}

?>