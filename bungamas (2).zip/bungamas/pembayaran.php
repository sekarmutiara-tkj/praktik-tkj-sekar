<?php
require_once 'includes/functions.php';

wajib_login('pembeli');

$id = (int)($_GET['id'] ?? 0);

$q = $pdo->prepare("
    SELECT p.*, u.nama AS nama_user
    FROM pesanan p
    JOIN users u ON u.id = p.user_id
    WHERE p.id = ? AND p.user_id = ?
");
$q->execute([$id, $_SESSION['user_id']]);
$pesanan = $q->fetch();

if (!$pesanan) {
    die('Pesanan tidak ditemukan.');
}

$q = $pdo->query("SELECT * FROM pengaturan WHERE id = 1");
$pengaturan = $q->fetch();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    if (
        !isset($_FILES['bukti_pembayaran']) ||
        $_FILES['bukti_pembayaran']['error'] !== UPLOAD_ERR_OK
    ) {
        $error = 'Silakan pilih bukti pembayaran terlebih dahulu.';
    } else {

        $file = $_FILES['bukti_pembayaran'];

        $allowed = ['jpg', 'jpeg', 'png', 'webp'];
        $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));

        if (!in_array($ext, $allowed)) {
            $error = 'Format file harus JPG, JPEG, PNG, atau WEBP.';
        } elseif ($file['size'] > 5 * 1024 * 1024) {
            $error = 'Ukuran file maksimal 5 MB.';
        } else {

            $folder = __DIR__ . '/uploads/bukti_pembayaran/';

            if (!is_dir($folder)) {
                mkdir($folder, 0777, true);
            }

            $namaFile = 'bukti_' . $pesanan['kode_pesanan'] . '_' . time() . '.' . $ext;

            $tujuan = $folder . $namaFile;

            if (move_uploaded_file($file['tmp_name'], $tujuan)) {

                $pathDatabase = 'uploads/bukti_pembayaran/' . $namaFile;

                $update = $pdo->prepare("
                    UPDATE pesanan
                    SET bukti_pembayaran = ?,
                        status_pembayaran = 'Menunggu Verifikasi'
                    WHERE id = ? AND user_id = ?
                ");

                $update->execute([
                    $pathDatabase,
                    $id,
                    $_SESSION['user_id']
                ]);

                header('Location: sukses.php?id=' . $id);
                exit;

            } else {
                $error = 'Gagal mengupload bukti pembayaran.';
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Pembayaran DANA - BungaMas</title>

    <link
        href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/css/bootstrap.min.css"
        rel="stylesheet"
    >

    <style>
        body {
            background: #f6f8f7;
        }

        .payment-box {
            max-width: 600px;
            margin: 50px auto;
        }

        .dana-box {
            background: #e9f5ff;
            border-radius: 15px;
            padding: 25px;
            border: 1px solid #cfe8ff;
        }

        .nomor-dana {
            font-size: 28px;
            font-weight: bold;
            letter-spacing: 1px;
        }

        .total {
            font-size: 25px;
            font-weight: bold;
        }
    </style>
</head>

<body>

<div class="container">

    <div class="payment-box">

        <div class="card shadow-sm border-0">

            <div class="card-body p-4">

                <h3 class="fw-bold mb-4">
                    Pembayaran DANA
                </h3>

                <?php if (!empty($error)): ?>
                    <div class="alert alert-danger">
                        <?= e($error) ?>
                    </div>
                <?php endif; ?>

                <div class="alert alert-success">
                    <strong>Pesanan berhasil dibuat.</strong><br>
                    Silakan lakukan pembayaran menggunakan DANA.
                </div>

                <div class="dana-box text-center mb-4">

                    <div class="text-muted mb-2">
                        Kirim pembayaran ke DANA
                    </div>

                    <div class="nomor-dana">
                        <?= e($pengaturan['nomor_dana']) ?>
                    </div>

                    <div class="mt-2">
                        a.n. <strong><?= e($pengaturan['nama_rekening']) ?></strong>
                    </div>

                </div>

                <div class="mb-4">

                    <div class="d-flex justify-content-between mb-2">
                        <span>Kode Pesanan</span>
                        <strong><?= e($pesanan['kode_pesanan']) ?></strong>
                    </div>

                    <div class="d-flex justify-content-between">

                        <span>Total Pembayaran</span>

                        <span class="total text-success">
                            <?= rupiah($pesanan['total']) ?>
                        </span>

                    </div>

                </div>

                <div class="alert alert-warning">

                    <strong>Petunjuk:</strong>

                    <ol class="mb-0 mt-2">
                        <li>Buka aplikasi DANA.</li>
                        <li>Kirim sesuai total pembayaran.</li>
                        <li>Pastikan nama penerima benar.</li>
                        <li>Simpan screenshot bukti transfer.</li>
                        <li>Upload bukti pembayaran di bawah.</li>
                    </ol>

                </div>

                <form method="POST" enctype="multipart/form-data">

                    <div class="mb-3">

                        <label class="form-label fw-bold">
                            Bukti Pembayaran
                        </label>

                        <input
                            type="file"
                            name="bukti_pembayaran"
                            class="form-control"
                            accept=".jpg,.jpeg,.png,.webp"
                            required
                        >

                        <small class="text-muted">
                            JPG, JPEG, PNG, WEBP. Maksimal 5 MB.
                        </small>

                    </div>

                    <button
                        type="submit"
                        class="btn btn-success w-100 py-2"
                    >
                        Kirim Bukti Pembayaran
                    </button>

                </form>

            </div>

        </div>

    </div>

</div>

</body>
</html>