<?php
require_once 'includes/functions.php';

wajib_login('pembeli');

$id = (int)($_GET['id'] ?? 0);

$q = $pdo->prepare("
    SELECT *
    FROM pesanan
    WHERE id = ? AND user_id = ?
");
$q->execute([$id, $_SESSION['user_id']]);

$pesanan = $q->fetch();

if (!$pesanan) {
    die('Pesanan tidak ditemukan.');
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Pesanan Berhasil - BungaMas</title>

    <link
        href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/css/bootstrap.min.css"
        rel="stylesheet"
    >

    <style>
        body {
            background: #f5f7f6;
        }

        .success-box {
            max-width: 650px;
            margin: 60px auto;
        }

        .success-icon {
            font-size: 60px;
        }
    </style>
</head>

<body>

<div class="container">

    <div class="success-box">

        <div class="card shadow-sm border-0">

            <div class="card-body text-center p-5">

                <div class="success-icon">
                    ✅
                </div>

                <h2 class="fw-bold mt-3">
                    Pesanan Berhasil!
                </h2>

                <p class="text-muted">
                    Terima kasih telah melakukan pembelian di BungaMas.
                </p>

                <hr>

                <div class="text-start">

                    <p>
                        <strong>Kode Pesanan:</strong><br>
                        <?= e($pesanan['kode_pesanan']) ?>
                    </p>

                    <p>
                        <strong>Total Pembayaran:</strong><br>

                        <span class="text-success fs-4 fw-bold">
                            <?= rupiah($pesanan['total']) ?>
                        </span>
                    </p>

                    <p>
                        <strong>Metode Pembayaran:</strong><br>
                        <?= e($pesanan['metode_pembayaran']) ?>
                    </p>

                    <p>
                        <strong>Status Pembayaran:</strong><br>

                        <?php if ($pesanan['status_pembayaran'] === 'Lunas'): ?>

                            <span class="badge bg-success">
                                Lunas
                            </span>

                        <?php elseif ($pesanan['status_pembayaran'] === 'Menunggu Verifikasi'): ?>

                            <span class="badge bg-warning text-dark">
                                Menunggu Verifikasi
                            </span>

                        <?php else: ?>

                            <span class="badge bg-danger">
                                Belum Bayar
                            </span>

                        <?php endif; ?>

                    </p>

                </div>

                <hr>

                <?php if (
                    $pesanan['metode_pembayaran'] === 'DANA'
                    && $pesanan['status_pembayaran'] === 'Belum Bayar'
                ): ?>

                    <div class="alert alert-info text-start">

                        <strong>Pembayaran DANA</strong>

                        <br><br>

                        Silakan lakukan pembayaran menggunakan DANA,
                        kemudian upload bukti pembayaran.

                    </div>

                    <a
                        href="pembayaran.php?id=<?= $pesanan['id'] ?>"
                        class="btn btn-primary btn-lg w-100 mb-3"
                    >
                        💳 Bayar Sekarang
                    </a>

                <?php elseif (
                    $pesanan['metode_pembayaran'] === 'Transfer Bank'
                    && $pesanan['status_pembayaran'] === 'Belum Bayar'
                ): ?>

                    <a
                        href="pembayaran.php?id=<?= $pesanan['id'] ?>"
                        class="btn btn-primary btn-lg w-100 mb-3"
                    >
                        🏦 Bayar Sekarang
                    </a>

                <?php elseif (
                    $pesanan['status_pembayaran'] === 'Menunggu Verifikasi'
                ): ?>

                    <div class="alert alert-warning">
                        Bukti pembayaran sudah dikirim.
                        Silakan tunggu verifikasi dari admin.
                    </div>

                <?php elseif (
                    $pesanan['status_pembayaran'] === 'Lunas'
                ): ?>

                    <div class="alert alert-success">
                        ✅ Pembayaran sudah diverifikasi oleh admin.
                    </div>

                <?php endif; ?>

                <a
                    href="toko.php"
                    class="btn btn-outline-secondary w-100"
                >
                    ← Kembali ke Toko
                </a>

            </div>

        </div>

    </div>

</div>

</body>
</html>