<?php

require_once __DIR__ . '/../includes/functions.php';

wajib_login('admin');

?>
<!doctype html>

<html lang="id">

<head>

    <meta charset="utf-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1"
    >

    <title>
        <?= e($title ?? 'Admin BungaMas') ?>
    </title>

    <!-- Bootstrap -->
    <link
        href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
        rel="stylesheet"
    >

    <!-- Font Awesome -->
    <link
        rel="stylesheet"
        href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css"
    >

    <!-- CSS Admin -->
    <link
        rel="stylesheet"
        href="../assets/shop.css"
    >

</head>

<body>

<!-- =========================
     NAVBAR ADMIN
========================= -->

<nav class="navbar navbar-dark bg-success">

    <div class="container">

        <!-- LOGO / DASHBOARD -->
        <a
            class="navbar-brand fw-bold"
            href="/BungaMas_Toko/bungamas/admin/dashboard.php"
        >
            <i class="fa-solid fa-seedling"></i>
            Admin BungaMas
        </a>


        <div class="d-flex gap-2">

            <!-- TOKO ADMIN -->
            <!-- Selalu menuju Kelola Produk -->
            <a
                class="btn btn-light btn-sm"
                href="/BungaMas_Toko/bungamas/admin/produk/index.php"
            >
                <i class="fa-solid fa-store"></i>
                Toko
            </a>


            <!-- PESANAN -->
            <a
                class="btn btn-light btn-sm"
                href="/BungaMas_Toko/bungamas/admin/pesanan.php"
            >
                <i class="fa-solid fa-receipt"></i>
                Pesanan
            </a>


            <!-- LOGOUT -->
            <a
                class="btn btn-warning btn-sm"
                href="/BungaMas_Toko/bungamas/logout.php"
            >
                <i class="fa-solid fa-right-from-bracket"></i>
                Logout
            </a>

        </div>

    </div>

</nav>


<!-- =========================
     CONTENT
========================= -->

<main class="py-4">

    <div class="container">