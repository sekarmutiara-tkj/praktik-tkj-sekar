<?php
require_once '../includes/functions.php';

wajib_login('admin');

header('Location: produk/index.php');
exit;
?>