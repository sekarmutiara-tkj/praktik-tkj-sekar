<?php
require_once '../../includes/functions.php';

wajib_login('admin');

$id = (int)($_GET['id'] ?? 0);

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['status_pesanan'])) {

    $status = $_POST['status_pesanan'];

    $status_valid = [
        'Menunggu',
        'Diproses',
        'Dikirim',
        'Selesai',
        'Dibatalkan'
    ];

    if (in_array($status, $status_valid)) {

        $update = $pdo->prepare("
            UPDATE pesanan
            SET status_pesanan = ?
            WHERE id = ?
        ");

        $update->execute([$status, $id]);

        header('Location: detail.php?id=' . $id);
        exit;
    }
}

if ($id <= 0) {
    die('ID pesanan tidak valid.');
}

/* Ambil data pesanan */
$q = $pdo->prepare("
    SELECT 
        p.*,
        u.nama AS nama_pembeli,
        u.email
    FROM pesanan p
    JOIN users u ON u.id = p.user_id
    WHERE p.id = ?
");

$q->execute([$id]);

$pesanan = $q->fetch();

if (!$pesanan) {
    die('Pesanan tidak ditemukan.');
}

/* Ambil detail produk */
$q = $pdo->prepare("
    SELECT *
    FROM pesanan_detail
    WHERE pesanan_id = ?
");

$q->execute([$id]);

$detail = $q->fetchAll();
?>

<!DOCTYPE html>
<html lang="id">

<head>

    <meta charset="UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Detail Pesanan - BungaMas</title>

    <link
        href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/css/bootstrap.min.css"
        rel="stylesheet"
    >

    <style>

        body {
            background: #f5f7f6;
        }

        .container {
            max-width: 1000px;
        }

        .card {
            border: none;
            border-radius: 15px;
        }

        .bukti-pembayaran {
            max-width: 450px;
            width: 100%;
            border-radius: 12px;
            border: 1px solid #ddd;
            cursor: pointer;
        }

        .label {
            color: #777;
            font-size: 14px;
        }

    </style>

</head>

<body>

<div class="container py-4">

    <!-- HEADER -->

    <div class="d-flex justify-content-between align-items-center mb-4">

        <div>

            <h2 class="fw-bold mb-1">
                Detail Pesanan
            </h2>

            <p class="text-muted mb-0">
                <?= e($pesanan['kode_pesanan']) ?>
            </p>

        </div>

        <a
            href="../pesanan.php"
            class="btn btn-outline-secondary"
        >
            ← Kembali
        </a>

    </div>


    <!-- INFORMASI PEMBELI -->

    <div class="card shadow-sm mb-4">

        <div class="card-body p-4">

            <h5 class="fw-bold mb-4">
                Informasi Pembeli
            </h5>

            <div class="row">

                <div class="col-md-6 mb-3">

                    <div class="label">
                        Nama Pembeli
                    </div>

                    <strong>
                        <?= e($pesanan['nama_pembeli']) ?>
                    </strong>

                </div>


                <div class="col-md-6 mb-3">

                    <div class="label">
                        Email
                    </div>

                    <strong>
                        <?= e($pesanan['email']) ?>
                    </strong>

                </div>


                <div class="col-md-6 mb-3">

                    <div class="label">
                        Nama Penerima
                    </div>

                    <strong>
                        <?= e($pesanan['nama_penerima']) ?>
                    </strong>

                </div>


                <div class="col-md-6 mb-3">

                    <div class="label">
                        Nomor WhatsApp
                    </div>

                    <strong>
                        <?= e($pesanan['no_whatsapp']) ?>
                    </strong>

                </div>


                <div class="col-12 mb-3">

                    <div class="label">
                        Alamat Pengiriman
                    </div>

                    <strong>
                        <?= e($pesanan['alamat']) ?>
                    </strong>

                    <br>

                    <?= e($pesanan['kota']) ?>,
                    <?= e($pesanan['provinsi']) ?>

                </div>

            </div>

        </div>

    </div>


    <!-- PRODUK -->

    <div class="card shadow-sm mb-4">

        <div class="card-body p-4">

            <h5 class="fw-bold mb-4">
                Detail Produk
            </h5>

            <div class="table-responsive">

                <table class="table align-middle">

                    <thead>

                        <tr>

                            <th>Produk</th>
                            <th>Harga</th>
                            <th>Jumlah</th>
                            <th>Subtotal</th>

                        </tr>

                    </thead>

                    <tbody>

                    <?php foreach ($detail as $d): ?>

                        <tr>

                            <td>
                                <?= e($d['nama_produk']) ?>
                            </td>

                            <td>
                                <?= rupiah($d['harga']) ?>
                            </td>

                            <td>
                                <?= e($d['jumlah']) ?>
                            </td>

                            <td>
                                <?= rupiah($d['subtotal']) ?>
                            </td>

                        </tr>

                    <?php endforeach; ?>

                    </tbody>

                </table>

            </div>


            <div class="text-end">

                <div>
                    Subtotal:
                    <strong>
                        <?= rupiah($pesanan['subtotal']) ?>
                    </strong>
                </div>

                <div>
                    Ongkir:
                    <strong>
                        <?= rupiah($pesanan['ongkir']) ?>
                    </strong>
                </div>

                <div class="fs-4 mt-2">

                    Total:

                    <strong class="text-success">
                        <?= rupiah($pesanan['total']) ?>
                    </strong>

                </div>

            </div>

        </div>

    </div>


    <!-- PEMBAYARAN -->

    <div class="card shadow-sm mb-4">

        <div class="card-body p-4">

            <h5 class="fw-bold mb-4">
                Informasi Pembayaran
            </h5>


            <div class="row mb-4">

                <div class="col-md-6 mb-3">

                    <div class="label">
                        Metode Pembayaran
                    </div>

                    <strong>
                        <?= e($pesanan['metode_pembayaran']) ?>
                    </strong>

                </div>


                <div class="col-md-6 mb-3">

                    <div class="label">
                        Status Pembayaran
                    </div>

                    <?php if ($pesanan['status_pembayaran'] === 'Lunas'): ?>

                        <span class="badge bg-success">
                            Lunas
                        </span>

                    <?php elseif ($pesanan['status_pembayaran'] === 'Menunggu Verifikasi'): ?>

                        <span class="badge bg-warning text-dark">
                            Menunggu Verifikasi
                        </span>

                    <?php else: ?>

                        <span class="badge bg-danger">
                            Belum Bayar
                        </span>

                    <?php endif; ?>

                </div>

            </div>


            <h6 class="fw-bold">
                Bukti Pembayaran
            </h6>


            <?php if (!empty($pesanan['bukti_pembayaran'])): ?>

                <div class="mt-3">

                    <a
                        href="../../<?= e($pesanan['bukti_pembayaran']) ?>"
                        target="_blank"
                    >

                        <img
                            src="../../<?= e($pesanan['bukti_pembayaran']) ?>"
                            class="bukti-pembayaran"
                            alt="Bukti Pembayaran"
                        >

                    </a>

                    <div class="text-muted mt-2">
                        Klik gambar untuk melihat ukuran penuh.
                    </div>

                </div>

            <?php else: ?>

                <div class="alert alert-secondary mt-3">
                    Pembeli belum mengupload bukti pembayaran.
                </div>

            <?php endif; ?>


            <?php if (
                $pesanan['status_pembayaran'] === 'Menunggu Verifikasi'
            ): ?>

                <hr class="my-4">

                <div class="d-flex gap-2">

                    <a
                        href="../verifikasi_pembayaran.php?id=<?= $pesanan['id'] ?>&aksi=terima"
                        class="btn btn-success"
                        onclick="return confirm('Apakah pembayaran ini benar dan ingin diterima?')"
                    >
                        ✓ Terima Pembayaran
                    </a>


                    <a
                        href="../verifikasi_pembayaran.php?id=<?= $pesanan['id'] ?>&aksi=tolak"
                        class="btn btn-danger"
                        onclick="return confirm('Apakah bukti pembayaran ini ingin ditolak?')"
                    >
                        ✕ Tolak Pembayaran
                    </a>

                </div>

            <?php endif; ?>

        </div>

    </div>


    <!-- STATUS PESANAN -->

    <div class="card shadow-sm mb-4">

        <div class="card-body p-4">

            <h5 class="fw-bold mb-3">
                Status Pesanan
            </h5>

            <form method="POST">

                <div class="mb-3">

                    <label class="form-label fw-bold">
                        Pilih Status Pesanan
                    </label>

                    <select
                        name="status_pesanan"
                        class="form-select"
                    >

                        <option
                            value="Menunggu"
                            <?= $pesanan['status_pesanan'] === 'Menunggu' ? 'selected' : '' ?>
                        >
                            Menunggu
                        </option>

                        <option
                            value="Diproses"
                            <?= $pesanan['status_pesanan'] === 'Diproses' ? 'selected' : '' ?>
                        >
                            Diproses
                        </option>

                        <option
                            value="Dikirim"
                            <?= $pesanan['status_pesanan'] === 'Dikirim' ? 'selected' : '' ?>
                        >
                            Dikirim
                        </option>

                        <option
                            value="Selesai"
                            <?= $pesanan['status_pesanan'] === 'Selesai' ? 'selected' : '' ?>
                        >
                            Selesai
                        </option>

                        <option
                            value="Dibatalkan"
                            <?= $pesanan['status_pesanan'] === 'Dibatalkan' ? 'selected' : '' ?>
                        >
                            Dibatalkan
                        </option>

                    </select>

                </div>

                <button
                    type="submit"
                    class="btn btn-primary"
                >
                    💾 Simpan Status
                </button>

            </form>

        </div>

    </div>


</div>

</body>

</html>