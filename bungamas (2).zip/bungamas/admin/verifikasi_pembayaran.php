<?php

require_once '../includes/functions.php';

wajib_login('admin');

$id = (int)($_GET['id'] ?? 0);
$aksi = $_GET['aksi'] ?? '';

if (!$id || !in_array($aksi, ['terima', 'tolak'])) {
    die('Permintaan tidak valid.');
}

if ($aksi === 'terima') {

    $q = $pdo->prepare("
        UPDATE pesanan
        SET status_pembayaran = 'Lunas'
        WHERE id = ?
    ");

    $q->execute([$id]);

} elseif ($aksi === 'tolak') {

    $q = $pdo->prepare("
        UPDATE pesanan
        SET status_pembayaran = 'Belum Bayar',
            bukti_pembayaran = NULL
        WHERE id = ?
    ");

    $q->execute([$id]);
}

header('Location: pesanan.php');
exit;