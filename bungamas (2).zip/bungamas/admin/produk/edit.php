<?php
require_once '../../includes/functions.php';

wajib_login('admin');

$id = (int)($_GET['id'] ?? 0);

$q = $pdo->prepare("SELECT * FROM produk WHERE id = ?");
$q->execute([$id]);

$produk = $q->fetch();

if (!$produk) {
    die('Produk tidak ditemukan.');
}

$title = 'Edit Produk';

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $nama_produk = trim($_POST['nama_produk'] ?? '');
    $deskripsi   = trim($_POST['deskripsi'] ?? '');
    $harga       = (float)($_POST['harga'] ?? 0);
    $satuan      = trim($_POST['satuan'] ?? 'pcs');
    $stok        = (int)($_POST['stok'] ?? 0);
    $aktif       = isset($_POST['aktif']) ? 1 : 0;

    if ($nama_produk === '') {
        $error = 'Nama produk wajib diisi.';
    } elseif ($harga < 0) {
        $error = 'Harga tidak boleh kurang dari 0.';
    } elseif ($stok < 0) {
        $error = 'Stok tidak boleh kurang dari 0.';
    }

    $gambar = $produk['gambar'];

    if (
        $error === '' &&
        isset($_FILES['gambar']) &&
        $_FILES['gambar']['error'] !== UPLOAD_ERR_NO_FILE
    ) {

        if ($_FILES['gambar']['error'] !== UPLOAD_ERR_OK) {

            $error = 'Upload gambar gagal.';

        } else {

            $allowed = [
                'jpg'  => 'image/jpeg',
                'jpeg' => 'image/jpeg',
                'png'  => 'image/png',
                'webp' => 'image/webp'
            ];

            $ext = strtolower(
                pathinfo($_FILES['gambar']['name'], PATHINFO_EXTENSION)
            );

            if (!isset($allowed[$ext])) {

                $error = 'Format gambar harus JPG, JPEG, PNG, atau WEBP.';

            } elseif ($_FILES['gambar']['size'] > 5 * 1024 * 1024) {

                $error = 'Ukuran gambar maksimal 5 MB.';

            } else {

                $folder = '../../uploads/produk/';

                if (!is_dir($folder)) {
                    mkdir($folder, 0777, true);
                }

                $namaFile =
                    'produk_' .
                    date('YmdHis') .
                    '_' .
                    random_int(1000, 9999) .
                    '.' .
                    $ext;

                $tujuan = $folder . $namaFile;

                if (move_uploaded_file($_FILES['gambar']['tmp_name'], $tujuan)) {

                    if (
                        !empty($produk['gambar']) &&
                        file_exists('../../' . $produk['gambar'])
                    ) {
                        unlink('../../' . $produk['gambar']);
                    }

                    $gambar = 'uploads/produk/' . $namaFile;

                } else {

                    $error = 'Gagal menyimpan gambar.';
                }
            }
        }
    }

    if ($error === '') {

        $q = $pdo->prepare("
            UPDATE produk
            SET
                nama_produk = ?,
                deskripsi = ?,
                harga = ?,
                satuan = ?,
                stok = ?,
                gambar = ?,
                aktif = ?
            WHERE id = ?
        ");

        $q->execute([
            $nama_produk,
            $deskripsi,
            $harga,
            $satuan,
            $stok,
            $gambar,
            $aktif,
            $id
        ]);

        header('Location: index.php');
        exit;
    }
}

require '../header.php';
?>

<div class="d-flex justify-content-between align-items-center mb-4">

    <div>
        <h1 class="fw-bold">Edit Produk</h1>
        <p class="text-muted mb-0">
            Ubah informasi produk BungaMas.
        </p>
    </div>

    <a href="index.php" class="btn btn-secondary">
        <i class="fa-solid fa-arrow-left"></i>
        Kembali
    </a>

</div>


<?php if ($error): ?>

    <div class="alert alert-danger">
        <?= e($error) ?>
    </div>

<?php endif; ?>


<div class="card border-0 shadow-sm">

    <div class="card-body">

        <form method="POST" enctype="multipart/form-data">

            <div class="mb-3">

                <label class="form-label fw-bold">
                    Nama Produk
                </label>

                <input
                    type="text"
                    name="nama_produk"
                    class="form-control"
                    value="<?= e($_POST['nama_produk'] ?? $produk['nama_produk']) ?>"
                    required
                >

            </div>


            <div class="mb-3">

                <label class="form-label fw-bold">
                    Deskripsi
                </label>

                <textarea
                    name="deskripsi"
                    class="form-control"
                    rows="4"
                ><?= e($_POST['deskripsi'] ?? $produk['deskripsi']) ?></textarea>

            </div>


            <div class="row">

                <div class="col-md-4 mb-3">

                    <label class="form-label fw-bold">
                        Harga
                    </label>

                    <input
                        type="number"
                        name="harga"
                        class="form-control"
                        min="0"
                        value="<?= e($_POST['harga'] ?? $produk['harga']) ?>"
                        required
                    >

                </div>


                <div class="col-md-4 mb-3">

                    <label class="form-label fw-bold">
                        Satuan
                    </label>

                    <input
                        type="text"
                        name="satuan"
                        class="form-control"
                        value="<?= e($_POST['satuan'] ?? $produk['satuan']) ?>"
                        required
                    >

                </div>


                <div class="col-md-4 mb-3">

                    <label class="form-label fw-bold">
                        Stok
                    </label>

                    <input
                        type="number"
                        name="stok"
                        class="form-control"
                        min="0"
                        value="<?= e($_POST['stok'] ?? $produk['stok']) ?>"
                        required
                    >

                </div>

            </div>


            <div class="mb-3">

                <label class="form-label fw-bold">
                    Foto Produk Saat Ini
                </label>

                <div class="mb-3">

                    <?php if (!empty($produk['gambar'])): ?>

                        <img
                            src="../../<?= e($produk['gambar']) ?>"
                            style="
                                width:180px;
                                height:180px;
                                object-fit:cover;
                                border-radius:15px;
                            "
                            alt="<?= e($produk['nama_produk']) ?>"
                        >

                    <?php else: ?>

                        <p class="text-muted">
                            Belum ada foto produk.
                        </p>

                    <?php endif; ?>

                </div>

            </div>


            <div class="mb-3">

                <label class="form-label fw-bold">
                    Ganti Foto
                </label>

                <input
                    type="file"
                    name="gambar"
                    class="form-control"
                    accept=".jpg,.jpeg,.png,.webp"
                >

                <small class="text-muted">
                    Kosongkan jika tidak ingin mengganti foto.
                </small>

            </div>


            <div class="form-check mb-4">

                <input
                    type="checkbox"
                    name="aktif"
                    class="form-check-input"
                    id="aktif"
                    <?= $produk['aktif'] ? 'checked' : '' ?>
                >

                <label
                    class="form-check-label"
                    for="aktif"
                >
                    Produk aktif dan dapat dibeli
                </label>

            </div>


            <button
                type="submit"
                class="btn btn-success"
            >
                <i class="fa-solid fa-save"></i>
                Simpan Perubahan
            </button>

        </form>

    </div>

</div>

<?php require '../footer.php'; ?>