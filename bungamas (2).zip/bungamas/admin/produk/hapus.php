<?php
require_once '../../includes/functions.php';

wajib_login('admin');

$id = (int)($_GET['id'] ?? 0);

$q = $pdo->prepare("SELECT * FROM produk WHERE id = ?");
$q->execute([$id]);

$produk = $q->fetch();

if (!$produk) {
    header('Location: index.php');
    exit;
}

/*
|--------------------------------------------------------------------------
| Cek apakah produk pernah digunakan dalam pesanan
|--------------------------------------------------------------------------
*/

$q = $pdo->prepare("
    SELECT COUNT(*)
    FROM pesanan_detail
    WHERE produk_id = ?
");

$q->execute([$id]);

$dipakai = (int)$q->fetchColumn();

if ($dipakai > 0) {

    /*
    Produk yang sudah pernah dibeli tidak dihapus
    supaya riwayat pesanan tetap aman.
    */

    $q = $pdo->prepare("
        UPDATE produk
        SET aktif = 0
        WHERE id = ?
    ");

    $q->execute([$id]);

} else {

    if (
        !empty($produk['gambar']) &&
        file_exists('../../' . $produk['gambar'])
    ) {
        unlink('../../' . $produk['gambar']);
    }

    $q = $pdo->prepare("
        DELETE FROM produk
        WHERE id = ?
    ");

    $q->execute([$id]);
}

header('Location: index.php');
exit;
?>