<?php
require_once '../../includes/functions.php';

wajib_login('admin');

$title = 'Kelola Produk';

require '../header.php';

$q = $pdo->query("
    SELECT *
    FROM produk
    ORDER BY id DESC
");

$produk = $q->fetchAll();
?>

<!-- HEADER -->
<div class="d-flex justify-content-between align-items-center mb-4">

    <div>
        <h1 class="fw-bold mb-1">
            Kelola Produk
        </h1>

        <p class="text-muted mb-0">
            Tambah, edit, hapus, dan kelola produk BungaMas.
        </p>
    </div>

    <a href="tambah.php" class="btn btn-success">
        <i class="fa-solid fa-plus"></i>
        Tambah Produk
    </a>

</div>


<!-- NAVIGASI ADMIN -->
<div class="mb-4">

    <a
        href="../dashboard.php"
        class="btn btn-outline-success me-2"
    >
        <i class="fa-solid fa-gauge"></i>
        Dashboard
    </a>

    <a
        href="../pesanan.php"
        class="btn btn-outline-primary me-2"
    >
        <i class="fa-solid fa-receipt"></i>
        Pesanan
    </a>

    

</div>


<!-- TABEL PRODUK -->
<div class="card border-0 shadow-sm">

    <div class="card-body">

        <div class="table-responsive">

            <table class="table table-hover align-middle">

                <thead class="table-success">

                    <tr>
                        <th width="80">Foto</th>
                        <th>Produk</th>
                        <th>Harga</th>
                        <th>Satuan</th>
                        <th>Stok</th>
                        <th>Status</th>
                        <th width="180">Aksi</th>
                    </tr>

                </thead>

                <tbody>

                <?php if (!$produk): ?>

                    <tr>

                        <td
                            colspan="7"
                            class="text-center py-5"
                        >

                            <i
                                class="fa-solid fa-box-open fa-3x text-muted mb-3"
                            ></i>

                            <p class="mb-0">
                                Belum ada produk.
                            </p>

                        </td>

                    </tr>

                <?php else: ?>

                    <?php foreach ($produk as $p): ?>

                        <tr>

                            <!-- FOTO -->
                            <td>

                                <?php if (!empty($p['gambar'])): ?>

                                    <img
                                        src="../../<?= e($p['gambar']) ?>"
                                        alt="<?= e($p['nama_produk']) ?>"
                                        style="
                                            width:70px;
                                            height:70px;
                                            object-fit:cover;
                                            border-radius:10px;
                                        "
                                    >

                                <?php else: ?>

                                    <div
                                        class="bg-light d-flex align-items-center justify-content-center"
                                        style="
                                            width:70px;
                                            height:70px;
                                            border-radius:10px;
                                        "
                                    >

                                        <i
                                            class="fa-solid fa-image text-muted"
                                        ></i>

                                    </div>

                                <?php endif; ?>

                            </td>


                            <!-- PRODUK -->
                            <td>

                                <strong>
                                    <?= e($p['nama_produk']) ?>
                                </strong>

                                <?php if (!empty($p['deskripsi'])): ?>

                                    <br>

                                    <small class="text-muted">
                                        <?= e($p['deskripsi']) ?>
                                    </small>

                                <?php endif; ?>

                            </td>


                            <!-- HARGA -->
                            <td>

                                <strong>
                                    <?= rupiah($p['harga']) ?>
                                </strong>

                            </td>


                            <!-- SATUAN -->
                            <td>
                                <?= e($p['satuan']) ?>
                            </td>


                            <!-- STOK -->
                            <td>

                                <?php if ($p['stok'] > 0): ?>

                                    <span class="badge bg-success">
                                        <?= e($p['stok']) ?>
                                    </span>

                                <?php else: ?>

                                    <span class="badge bg-danger">
                                        Habis
                                    </span>

                                <?php endif; ?>

                            </td>


                            <!-- STATUS -->
                            <td>

                                <?php if ($p['aktif'] == 1): ?>

                                    <span class="badge bg-success">
                                        Aktif
                                    </span>

                                <?php else: ?>

                                    <span class="badge bg-secondary">
                                        Tidak Aktif
                                    </span>

                                <?php endif; ?>

                            </td>


                            <!-- AKSI -->
                            <td>

                                <a
                                    href="edit.php?id=<?= $p['id'] ?>"
                                    class="btn btn-sm btn-warning"
                                >
                                    <i class="fa-solid fa-pen"></i>
                                    Edit
                                </a>

                                <a
                                    href="hapus.php?id=<?= $p['id'] ?>"
                                    class="btn btn-sm btn-danger"
                                    onclick="return confirm('Yakin ingin menghapus produk ini?')"
                                >
                                    <i class="fa-solid fa-trash"></i>
                                    Hapus
                                </a>

                            </td>

                        </tr>

                    <?php endforeach; ?>

                <?php endif; ?>

                </tbody>

            </table>

        </div>

    </div>

</div>


<?php require '../footer.php'; ?>