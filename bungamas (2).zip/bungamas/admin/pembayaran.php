<?php
require_once '../includes/functions.php';

wajib_login('admin');

$q = $pdo->query("
    SELECT
        p.*,
        u.nama AS nama_pembeli,
        u.email
    FROM pesanan p
    JOIN users u ON u.id = p.user_id
    ORDER BY p.created_at DESC
");

$pesanan = $q->fetchAll();
?>

<!DOCTYPE html>
<html lang="id">

<head>

    <meta charset="UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Pesanan - Admin BungaMas</title>

    <link
        href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/css/bootstrap.min.css"
        rel="stylesheet"
    >

    <style>

        body {
            background: #f5f7f6;
        }

        .container {
            max-width: 1200px;
        }

        .bukti-img {
            width: 100px;
            height: 100px;
            object-fit: cover;
            border-radius: 10px;
            border: 1px solid #ddd;
        }

    </style>

</head>

<body>

<div class="container py-4">

    <div class="d-flex justify-content-between align-items-center mb-4">

        <div>
            <h2 class="fw-bold mb-1">
                Pesanan Masuk
            </h2>

            <p class="text-muted mb-0">
                Kelola pesanan dan pembayaran pelanggan
            </p>
        </div>

        <a
            href="dashboard.php"
            class="btn btn-outline-secondary"
        >
            ← Dashboard
        </a>

    </div>


    <?php if (!$pesanan): ?>

        <div class="alert alert-info">
            Belum ada pesanan.
        </div>

    <?php else: ?>

        <div class="card shadow-sm border-0">

            <div class="card-body">

                <div class="table-responsive">

                    <table class="table table-hover align-middle">

                        <thead>

                            <tr>

                                <th>No</th>

                                <th>Pesanan</th>

                                <th>Pembeli</th>

                                <th>Total</th>

                                <th>Pembayaran</th>

                                <th>Bukti</th>

                                <th>Status</th>

                                <th>Aksi</th>

                            </tr>

                        </thead>

                        <tbody>

                        <?php foreach ($pesanan as $i => $p): ?>

                            <tr>

                                <td>
                                    <?= $i + 1 ?>
                                </td>


                                <td>

                                    <strong>
                                        <?= e($p['kode_pesanan']) ?>
                                    </strong>

                                    <br>

                                    <small class="text-muted">
                                        <?= e($p['created_at']) ?>
                                    </small>

                                </td>


                                <td>

                                    <?= e($p['nama_pembeli']) ?>

                                    <br>

                                    <small class="text-muted">
                                        <?= e($p['email']) ?>
                                    </small>

                                </td>


                                <td>

                                    <strong>
                                        <?= rupiah($p['total']) ?>
                                    </strong>

                                </td>


                                <td>

                                    <?= e($p['metode_pembayaran']) ?>

                                    <br>

                                    <?php if ($p['status_pembayaran'] === 'Lunas'): ?>

                                        <span class="badge bg-success">
                                            Lunas
                                        </span>

                                    <?php elseif ($p['status_pembayaran'] === 'Menunggu Verifikasi'): ?>

                                        <span class="badge bg-warning text-dark">
                                            Menunggu Verifikasi
                                        </span>

                                    <?php else: ?>

                                        <span class="badge bg-danger">
                                            Belum Bayar
                                        </span>

                                    <?php endif; ?>

                                </td>


                                <td>

                                    <?php if (!empty($p['bukti_pembayaran'])): ?>

                                        <a
                                            href="../<?= e($p['bukti_pembayaran']) ?>"
                                            target="_blank"
                                        >

                                            <img
                                                src="../<?= e($p['bukti_pembayaran']) ?>"
                                                class="bukti-img"
                                                alt="Bukti Pembayaran"
                                            >

                                        </a>

                                        <br>

                                        <small>
                                            Klik foto untuk memperbesar
                                        </small>

                                    <?php else: ?>

                                        <span class="text-muted">
                                            Belum ada
                                        </span>

                                    <?php endif; ?>

                                </td>


                                <td>

                                    <?= e($p['status_pesanan']) ?>

                                </td>


                                <td>

                                    <?php if (
                                        $p['status_pembayaran'] === 'Menunggu Verifikasi'
                                    ): ?>

                                        <a
                                            href="verifikasi_pembayaran.php?id=<?= $p['id'] ?>&aksi=terima"
                                            class="btn btn-success btn-sm mb-1"
                                            onclick="return confirm('Terima pembayaran ini?')"
                                        >
                                            ✓ Terima
                                        </a>

                                        <a
                                            href="verifikasi_pembayaran.php?id=<?= $p['id'] ?>&aksi=tolak"
                                            class="btn btn-danger btn-sm"
                                            onclick="return confirm('Tolak pembayaran ini?')"
                                        >
                                            ✕ Tolak
                                        </a>

                                    <?php else: ?>

                                        <span class="text-muted">
                                            -
                                        </span>

                                    <?php endif; ?>

                                </td>

                            </tr>

                        <?php endforeach; ?>

                        </tbody>

                    </table>

                </div>

            </div>

        </div>

    <?php endif; ?>

</div>

</body>
</html>