<?php
require_once '../includes/functions.php';

wajib_login('admin');

/* Ambil semua pesanan */
$q = $pdo->query("
    SELECT 
        p.*,
        u.nama AS nama_pembeli
    FROM pesanan p
    JOIN users u ON u.id = p.user_id
    ORDER BY p.created_at DESC
");

$pesanan = $q->fetchAll();
?>

<!DOCTYPE html>
<html lang="id">
<head>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Pesanan - Admin BungaMas</title>

    <link
        href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
        rel="stylesheet"
    >

    <style>
        body {
            background: #f5f7f6;
        }

        .container {
            margin-top: 35px;
        }

        .card {
            border: none;
            border-radius: 15px;
            box-shadow: 0 4px 15px rgba(0,0,0,.07);
        }

        .table {
            vertical-align: middle;
        }
    </style>

</head>

<body>

<div class="container">

    <div class="d-flex justify-content-between align-items-center mb-4">

        <div>
            <h2>📦 Pesanan</h2>
            <p class="text-muted mb-0">
                Daftar pesanan pelanggan BungaMas
            </p>
        </div>

        <a href="dashboard.php" class="btn btn-secondary">
            ← Dashboard
        </a>

    </div>


    <div class="card">

        <div class="card-body">

            <?php if (!$pesanan): ?>

                <div class="text-center py-5">

                    <h5>Belum ada pesanan</h5>

                    <p class="text-muted">
                        Pesanan dari pembeli akan muncul di sini.
                    </p>

                </div>

            <?php else: ?>

                <div class="table-responsive">

                    <table class="table table-hover">

                        <thead>

                            <tr>
                                <th>No</th>
                                <th>Kode Pesanan</th>
                                <th>Pembeli</th>
                                <th>Total</th>
                                <th>Pembayaran</th>
                                <th>Status Pesanan</th>
                                <th>Tanggal</th>
                                <th>Aksi</th>
                            </tr>

                        </thead>

                        <tbody>

                        <?php $no = 1; ?>

                        <?php foreach ($pesanan as $p): ?>

                            <tr>

                                <td>
                                    <?= $no++ ?>
                                </td>

                                <td>
                                    <strong>
                                        <?= e($p['kode_pesanan']) ?>
                                    </strong>
                                </td>

                                <td>
                                    <?= e($p['nama_pembeli']) ?>
                                </td>

                                <td>
                                    <strong>
                                        <?= rupiah($p['total']) ?>
                                    </strong>
                                </td>

                                <td>

                                    <?php if ($p['status_pembayaran'] === 'Lunas'): ?>

                                        <span class="badge bg-success">
                                            Lunas
                                        </span>

                                    <?php elseif ($p['status_pembayaran'] === 'Menunggu Verifikasi'): ?>

                                        <span class="badge bg-warning text-dark">
                                            Menunggu Verifikasi
                                        </span>

                                    <?php else: ?>

                                        <span class="badge bg-secondary">
                                            Belum Bayar
                                        </span>

                                    <?php endif; ?>

                                </td>

                                <td>

                                    <?php if ($p['status_pesanan'] === 'Selesai'): ?>

                                        <span class="badge bg-success">
                                            Selesai
                                        </span>

                                    <?php elseif ($p['status_pesanan'] === 'Dibatalkan'): ?>

                                        <span class="badge bg-danger">
                                            Dibatalkan
                                        </span>

                                    <?php elseif ($p['status_pesanan'] === 'Diproses'): ?>

                                        <span class="badge bg-primary">
                                            Diproses
                                        </span>

                                    <?php elseif ($p['status_pesanan'] === 'Dikirim'): ?>

                                        <span class="badge bg-info text-dark">
                                            Dikirim
                                        </span>

                                    <?php else: ?>

                                        <span class="badge bg-warning text-dark">
                                            Menunggu
                                        </span>

                                    <?php endif; ?>

                                </td>

                                <td>
                                    <?= date('d/m/Y H:i', strtotime($p['created_at'])) ?>
                                </td>

                                <td>

                                    <a
                                        href="pesanan/detail.php?id=<?= $p['id'] ?>"
                                        class="btn btn-sm btn-primary"
                                    >
                                        👁 Detail
                                    </a>

                                </td>

                            </tr>

                        <?php endforeach; ?>

                        </tbody>

                    </table>

                </div>

            <?php endif; ?>

        </div>

    </div>

</div>

</body>
</html>